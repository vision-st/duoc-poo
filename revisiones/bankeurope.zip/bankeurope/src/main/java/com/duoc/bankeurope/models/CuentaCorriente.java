package com.duoc.bankeurope.models;

public class CuentaCorriente extends CuentaBancaria {
    // Atributos
    private int sobregiro;

    // Constructor
    public CuentaCorriente(int sobregiro) {
        super(); // hereda de CuentaBancaria
        this.sobregiro = sobregiro;
    }

    // Getters
    public double getSobregiro() {
        return sobregiro;
    }

    // Métodos
    @Override
    public void giro(int monto) {
        if (monto > 0 && (getSaldo() + sobregiro) >= monto) {
            super.giro(monto);
        } else if (monto > (getSaldo() + sobregiro)) {
            System.out.println("El monto a girar no puede exceder el saldo disponible más el sobregiro permitido.");
        } else {
            System.out.println("El monto a girar debe ser mayor a cero.");
        }
    }

    @Override
    public void calcularIntereses() {
        System.out.println(
                "La cuenta corriente no genera intereses. Si estás interesado en intereses, considera abrir una cuenta de ahorros.");
    }
}

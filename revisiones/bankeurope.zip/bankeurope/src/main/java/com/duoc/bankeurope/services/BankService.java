package com.duoc.bankeurope.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.duoc.bankeurope.models.*;

/*
 * BankService.java
 * Implementa los métodos del servicio bancario
*/
public class BankService {

    private List<Cliente> clientes;
    private Scanner sc;

    public BankService() {
        clientes = new ArrayList<>();
        sc = new Scanner(System.in);
    }

    public void registrarCliente() {
        String rut = solicitarRut();

        if (buscarCliente(rut) != null) {
            System.out.println("Ya existe un cliente con ese RUT.");
            return;
        }

        System.out.print("Ingrese el nombre del cliente: ");
        String nombre = sc.nextLine();

        System.out.print("Ingrese el apellido paterno: ");
        String apellidoPaterno = sc.nextLine();

        System.out.print("Ingrese el apellido materno: ");
        String apellidoMaterno = sc.nextLine();

        System.out.print("Ingrese el domicilio: ");
        String domicilio = sc.nextLine();

        System.out.print("Ingrese la comuna: ");
        String comuna = sc.nextLine();

        System.out.print("Ingrese el teléfono: ");
        String telefono = sc.nextLine();

        CuentaBancaria cuenta = crearCuentaInteractiva();
        if (cuenta == null) return;

        Cliente cliente = new Cliente(rut, nombre, apellidoPaterno, apellidoMaterno, domicilio, comuna, telefono);
        cliente.addCuenta(cuenta);
        clientes.add(cliente);

        System.out.println("Cliente y cuenta registrados exitosamente.");
    }

    public void verDatosCliente() {
        Cliente cliente = solicitarCliente();
        if (cliente != null) {
            cliente.mostrarInformacionCliente();
        }
    }

    public void realizarDeposito() {
        Cliente cliente = solicitarCliente();
        if (cliente == null)
            return;

        CuentaBancaria cuenta = seleccionarCuentaCliente(cliente);
        if (cuenta == null)
            return;

        System.out.print("Ingrese monto a depositar: ");
        int monto = sc.nextInt();
        sc.nextLine();

        cuenta.depositar(monto);
        System.out.println("Depósito realizado exitosamente.");
    }

    public void realizarGiro() {
        Cliente cliente = solicitarCliente();
        if (cliente == null)
            return;

        CuentaBancaria cuenta = seleccionarCuentaCliente(cliente);
        if (cuenta == null)
            return;

        System.out.print("Ingrese monto a girar: ");
        int monto = sc.nextInt();
        sc.nextLine();

        cuenta.giro(monto);
        System.out.println("Giro realizado exitosamente.");
    }

    public void consultarSaldo() {
        Cliente cliente = solicitarCliente();
        if (cliente == null)
            return;

        CuentaBancaria cuenta = seleccionarCuentaCliente(cliente);
        if (cuenta == null)
            return;

        System.out.println("Saldo actual: $" + cuenta.getSaldo());
    }

    // MÉTODOS AUXILIARES

    private Cliente buscarCliente(String rut) {
        for (Cliente c : clientes) {
            if (c.getRut().equalsIgnoreCase(rut)) {
                return c;
            }
        }
        return null;
    }

    private Cliente solicitarCliente() {
        String rut = solicitarRut();
        Cliente cliente = buscarCliente(rut);
        if (cliente == null) {
            System.out.println("Cliente no encontrado.");
            return null;
        }
        return cliente;
    }

    private String solicitarRut() {
        System.out.print("Ingrese RUT del cliente: ");
        return sc.nextLine();
    }

    private CuentaBancaria crearCuentaInteractiva() {
        System.out.println("Seleccione tipo de cuenta:");
        System.out.println("1. Cuenta Corriente");
        System.out.println("2. Cuenta Ahorros");
        System.out.println("3. Cuenta Digital");

        int opcion = sc.nextInt();
        sc.nextLine(); // limpiar buffer

        switch (opcion) {
            case 1:
                System.out.print("Ingrese monto de sobregiro permitido: ");
                int sobregiro = sc.nextInt();
                return new CuentaCorriente(sobregiro);
            case 2:
                System.out.print("Ingrese tasa de interés: ");
                double tasaInteresAhorros = sc.nextDouble();
                return new CuentaAhorros(tasaInteresAhorros);
            case 3:
                System.out.print("Ingrese tasa de interés: ");
                double tasaInteresDigital = sc.nextDouble();
                return new CuentaDigital(tasaInteresDigital);
            default:
                System.out.println("Opción inválida.");
                return null;
        }
    }

    private CuentaBancaria seleccionarCuentaCliente(Cliente cliente) {
        List<CuentaBancaria> cuentas = cliente.getCuentas();

        if (cuentas.isEmpty()) {
            System.out.println("El cliente no tiene cuentas registradas.");
            return null;
        }

        System.out.println("Seleccione cuenta:");
        for (int i = 0; i < cuentas.size(); i++) {
            System.out.println((i + 1) + ". " + cuentas.get(i).getClass().getSimpleName());
        }

        int seleccion = sc.nextInt();
        sc.nextLine();

        if (seleccion < 1 || seleccion > cuentas.size()) {
            System.out.println("Selección inválida.");
            return null;
        }

        return cuentas.get(seleccion - 1);
    }
}

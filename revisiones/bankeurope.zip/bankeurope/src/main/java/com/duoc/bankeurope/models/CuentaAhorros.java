package com.duoc.bankeurope.models;

public class CuentaAhorros extends CuentaBancaria {
    // Atributos
    protected double tasaInteres;

    // Constructor
    public CuentaAhorros(double tasaInteres){
        super();
        this.tasaInteres = tasaInteres;
    }


    // Métodos

    @Override
    public void calcularIntereses(){
        int interes = (int) (getSaldo() * tasaInteres / 100);
        depositar(interes);
        System.out.println("Intereses calculados y depositados: " + interes); 
    }

    public double getTasaInteres(){
        return tasaInteres;
    }

}

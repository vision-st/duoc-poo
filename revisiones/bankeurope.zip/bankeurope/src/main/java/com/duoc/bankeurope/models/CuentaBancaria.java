package com.duoc.bankeurope.models;
// Interfaz CuentaBancaria
public abstract class CuentaBancaria {
    // Atributos
    protected static int contadorCuenta = 0;
    protected int numeroCuenta;
    protected int saldo;

    // Constructor
    public CuentaBancaria(){
        this.numeroCuenta = ++contadorCuenta;
        this.saldo = 0;
    }

    // Getters
    public int getNumeroCuenta(){
        return numeroCuenta;
    }

    public int getSaldo(){
        return saldo;
    }

    // Métodos
    public void depositar(int monto){
        if (monto > 0){
            saldo += monto;
            System.out.println("Depósito realizado con éxito.");
            System.out.println("Nuevo saldo: " + saldo );
        } else {
            System.out.println("El monto a depositar debe ser mayor a cero.");
        }
    }

    public void giro(int monto){
        if(monto > 0 && monto <= saldo){
            saldo -= monto;
            System.out.println("Giro realizado con éxito.");
            System.out.println("Nuevo saldo: " + saldo);
        } else if (monto > saldo){
            System.out.println("El monto a girar no puede exceder el saldo disponible en la cuenta.");
        } else {
            System.out.println("El monto a girar debe ser mayor a cero.");
        }
    }

    public void calcularIntereses(){}
}

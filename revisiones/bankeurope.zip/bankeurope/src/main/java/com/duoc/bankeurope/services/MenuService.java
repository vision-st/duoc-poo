package com.duoc.bankeurope.services;

import java.util.Scanner;

public class MenuService {

    String border = "----------------------------------------";

    public void iniciar() {
        Scanner sc = new Scanner(System.in);
        BankService bankService = new BankService();
        boolean salir = false;

        do {
            mostrarMenu();
            int opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1:
                    bankService.registrarCliente();
                    break;
                case 2:
                    bankService.verDatosCliente();
                    break;
                case 3:
                    bankService.realizarDeposito();
                    break;
                case 4:
                    bankService.realizarGiro();
                    break;
                case 5:
                    bankService.consultarSaldo();
                    break;
                case 6:
                    salir = true;
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        } while (!salir);

        sc.close();
    }

    public void mostrarMenu() {
        System.out.println(border);
        System.out.println("          BankEurope - Menú Principal");
        System.out.println(border);
        System.out.println("1. Registrar cliente");
        System.out.println("2. Ver datos de cliente");
        System.out.println("3. Depositar");
        System.out.println("4. Girar");
        System.out.println("5. Consultar saldo");
        System.out.println("6. Salir");
        System.out.println(border);
        System.out.print("> Seleccione una opción: ");
    }

}

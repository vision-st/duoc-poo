package com.duoc.bankeurope.models;

public class CuentaDigital extends CuentaBancaria {
    // Atributos
    private double tasaInteres;

    // Constructor
    public CuentaDigital(double tasaInteres) {
        super(); // hereda de CuentaBancaria
        this.tasaInteres = tasaInteres;
    }

    // Métodos
    @Override
    public void calcularIntereses() {
        int interes = (int) (getSaldo() * tasaInteres / 100);
        depositar(interes);
        System.out.println("Intereses calculados y depositados: " + interes);
    }

    public double getTasaInteres() {
        return tasaInteres;
    }

}

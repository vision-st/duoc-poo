package com.duoc.bankeurope.app;

import com.duoc.bankeurope.services.MenuService;

public class Main 
{
    public static void main( String[] args )
    {
        MenuService menu = new MenuService();
        menu.iniciar();
    }
}

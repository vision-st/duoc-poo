package com.duoc.bankeurope.models;

import java.util.ArrayList;
import java.util.List;

import com.duoc.bankeurope.interfaces.InfoCliente;

public class Cliente implements InfoCliente {
    // Atributos
    protected String rut;
    protected String nombre;
    protected String apellidoPaterno;
    protected String apellidoMaterno;
    protected String domicilio;
    protected String comuna;
    protected String telefono;
    protected List<CuentaBancaria> cuentas;

    // Constructor
    public Cliente(String rut, String nombre, String apellidoPaterno, String apellidoMaterno, String domicilio,
            String comuna, String telefono) {
        if (rut.length() < 11 || rut.length() > 12) {
            System.out.println("Error al intentar registrar el RUT: " + rut);
            throw new IllegalArgumentException("Escriba un RUT válido. El RUT debe tener entre 11 y 12 caracteres.");
        }

        this.rut = rut;
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.domicilio = domicilio;
        this.comuna = comuna;
        this.telefono = telefono;
        this.cuentas = new ArrayList<>();
    }

    // Getters
    public String getRut() {
        return rut;
    }

    public String getNombreCompleto() {
        return nombre + " " + apellidoPaterno + " " + apellidoMaterno;
    }

    public List<CuentaBancaria> getCuentas() {
        return cuentas;
    }

    public void addCuenta(CuentaBancaria cuenta) {
        cuentas.add(cuenta);
    }

    public CuentaBancaria buscarCuentaPorNumero(int numeroCuenta) {
        for (CuentaBancaria cuenta : cuentas) {
            if (cuenta.getNumeroCuenta() == numeroCuenta) {
                return cuenta;
            }
        }
        return null; // Si no se encuentra la cuenta
    }

    public boolean tieneCuentaDeTipo(Class<?> tipoCuenta) {
        for (CuentaBancaria c : cuentas) {
            if (c.getClass().equals(tipoCuenta)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void mostrarInformacionCliente() {
        System.out.println("Rut: " + rut);
        System.out.println("Nombre: " + nombre);
        System.out.println("Apellido Paterno: " + apellidoPaterno);
        System.out.println("Apellido Materno: " + apellidoMaterno);
        System.out.println("Domicilio: " + domicilio);
        System.out.println("Comuna: " + comuna);
        System.out.println("Teléfono: " + telefono);
        System.out.println("Cuentas:");
        for (CuentaBancaria cuenta : cuentas) {
            System.out.println("  Número de Cuenta: " + cuenta.getNumeroCuenta() + " | Saldo: $" + cuenta.getSaldo());
        }
    }

}

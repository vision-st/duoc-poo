package com.duoc.bankeurope.interfaces;

public interface InfoCliente {
    /**
     * Método para mostrar la información del cliente.
     */
    public void mostrarInformacionCliente();
}
